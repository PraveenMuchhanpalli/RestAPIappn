package com.example.restApi.Modal;

import java.time.LocalDateTime;

public class EmployeeModal {
	
	private String empName;
    private String dept;
    private Boolean active;
    private Double sal;
    private LocalDateTime createdDate;
    private LocalDateTime updateDate;
   
	public LocalDateTime getUpdateDate() {
		return updateDate;
	}
	public void setUpdateDate(LocalDateTime localDateTime) {
		this.updateDate = localDateTime;
	}
	public EmployeeModal(String empName, String dept, Boolean active, Double sal) {
		super();
		this.empName = empName;
		this.dept = dept;
		this.active = active;
		this.sal = sal;
	}
	public LocalDateTime getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(LocalDateTime localDateTime) {
		this.createdDate = localDateTime;
	}
	public EmployeeModal() {
		// TODO Auto-generated constructor stub
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public String getDept() {
		return dept;
	}
	public void setDept(String dept) {
		this.dept = dept;
	}
	public Boolean getActive() {
		return active;
	}
	public void setActive(Boolean active) {
		this.active = active;
	}
	public Double getSal() {
		return sal;
	}
	public void setSal(Double sal) {
		this.sal = sal;
	}
	
	
}
