package com.example.restApi.EmployeeRestAPI.employee;

import java.time.LocalDateTime;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.example.restApi.Modal.EmployeeModal;

@RestController
public class EmployeeController {
	
	private EmployeeRepositary repo;
	@Autowired
	private EmployeeService service;
	
	public EmployeeController(EmployeeRepositary repo,EmployeeService service) {
		this.repo=repo;
		this.service=service;
	}
	 
	@GetMapping("/getallemployee")
	public List<Employee> display() {
                                                                                      //display all entities
		return repo.findAll();

	}

	@PostMapping("/addemployees")
	public ResponseEntity<String> saveEmployee(@RequestBody List<Employee> employee) {
		
		for (Employee employee2 : employee) {
			                                                                            //adding multiple entities 
		employee2.setCreatedTime(LocalDateTime.now());
		}
		 repo.saveAll(employee);
		 return ResponseEntity.ok("Employees are added successfully");
		
	}
	@GetMapping("/employee/{dept}")
	public List<Employee> displayByDept(@PathVariable String dept) {
                                                                      //retrieving only required records based on dept
		return repo.findByDept(dept);
		

	}
	
	@DeleteMapping("/deleteemployee/{id}")
	public List<Employee> deleteEmployee(@PathVariable int id) {
		                                                                                //delete single record by id
	 repo.deleteById(id);
	 return repo.findAll();
	}
	
	@PutMapping("/updateemployee/{id}")
	public List<Employee> updateById(@PathVariable int id,@RequestBody Employee employee)
	{
		
		employee.setUpdatedTime(LocalDateTime.now());                                           //updating 
		repo.save(employee);
		return repo.findAll();
		
		}
	 @DeleteMapping("/deleteemployee/byids")
	    public ResponseEntity<String> deleteEntities(@RequestBody List<Integer> Ids) {
		 
		 service.deleteEntitiesByIds(Ids);                                       
		 return ResponseEntity.ok("Employees are deleted successfully");           //Deleting multiple records at a time 
	    }

	@GetMapping("/dispalyallemployee")
	public ResponseEntity<List<EmployeeModal>> displayAll(){
		
		List<Employee> emp=repo.findAll();
		
		List<EmployeeModal> employees=emp.stream()
				.map(employeee ->{
					EmployeeModal empmodal1 = new EmployeeModal();                     //Displaying only required fields
					empmodal1.setEmpName(employeee.getEmpName());
					empmodal1.setDept(employeee.getDept());
					empmodal1.setSal(employeee.getSalary());
					empmodal1.setActive(employeee.isActive());
					empmodal1.setCreatedDate(employeee.getCreatedTime());
					empmodal1.setUpdateDate(employeee.getUpdatedTime());
					return empmodal1;
			
		}).collect(Collectors.toList());
		
		return ResponseEntity.ok(employees);

	}
	@DeleteMapping("/deleteallemployee")
	public ResponseEntity<String> deleteAll() {                                           //deleting all

		 repo.deleteAll();
		 return ResponseEntity.ok("All employees are Deleted");
	}

	@PutMapping("/updateall")
	public ResponseEntity<String> updateAll(@RequestBody List<Employee> emp1){
		
		for (Employee employee : emp1) {
			int id =employee.getId();
			Employee emp11=repo.findById(id).orElse(null);
			emp11.setEmpName(employee.getEmpName());
			emp11.setDept(employee.getDept());                         //updating multiple employees 
			emp11.setSalary(employee.getSalary());
			emp11.setActive(employee.isActive());
			emp11.setCreatedTime(employee.getCreatedTime());
			emp11.setUpdatedTime(LocalDateTime.now());
			
			repo.save(emp11);
		}
		
		
		return ResponseEntity.ok("Updated");
		
	}
//	@PostMapping("/saveOrupdate")
//	public ResponseEntity<String> saveOrUpdate(@RequestBody List<Employee> emp1) {
//		return service.saveOrUpdate(emp1);
//		}
//	
	
	
	
	@PostMapping("/saveupdate")
	public void saveupdate(@RequestBody List<Employee> emp1) {
		
		for (Employee employee : emp1) {
			employee.setCreatedTime(LocalDateTime.now());
		}
		repo.saveAll(emp1);
	}
	
	@PostMapping("/saveOrupdate")
	public  ResponseEntity<String>   saveOrUpdate(@RequestBody List<AnotherClass> another) {
		service.saveOrUpdate(another);
		return ResponseEntity.ok("Done");
	}
}
	
	
	
	 



























 
 