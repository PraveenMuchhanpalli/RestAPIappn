package com.example.restApi.EmployeeRestAPI.employee;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
@Repository
public interface EmployeeRepositary extends JpaRepository<Employee, Integer>{

	public List<Employee> findByDept(String department);
	
	 
}
