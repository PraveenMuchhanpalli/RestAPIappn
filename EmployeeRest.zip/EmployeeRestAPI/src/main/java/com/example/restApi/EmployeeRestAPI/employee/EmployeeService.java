package com.example.restApi.EmployeeRestAPI.employee;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
@Service
public class EmployeeService {

	 @Autowired
	    private  EmployeeRepositary entityRepository;

	    public  void deleteEntitiesByIds(List<Integer> entityIds)
         {
	        entityIds.forEach(entityRepository::deleteById);
	    }
	    
	    
	   
//		public ResponseEntity<String> saveOrUpdate(@RequestBody List<Employee> emp1) {
//
//			for (Employee employee : emp1) 
//			{
//				int id = employee.getId();
//				if (employee.getId() != 0)
//				{
//
//					Employee emp11 = entityRepository.findById(id).orElse(null);
//					emp11.setEmpName(employee.getEmpName());
//					emp11.setDept(employee.getDept());
//					emp11.setSalary(employee.getSalary());
//					emp11.setActive(employee.isActive());
//					emp11.setCreatedTime(employee.getCreatedTime());
//					emp11.setUpdatedTime(LocalDateTime.now());
//					entityRepository.save(emp11);
//
//				}
//
//				else {
//					  for (Employee employee2 : emp1) {
//					  employee2.setCreatedTime(LocalDateTime.now());
//					}
//					entityRepository.saveAll(emp1);
//					return ResponseEntity.ok("added");
//				}
//
//			}
//			return ResponseEntity.ok("Updated");
//		}
	    
	    public void  saveOrUpdate(@RequestBody List<AnotherClass> another)
	    {
	    	List<Employee> emplist=new ArrayList<Employee>();
	    	for (AnotherClass employee : another) {
				Employee entityBean=new Employee();
				if (employee.getId()!=0) {
					entityBean.setId(employee.getId());
					entityBean.setUpdatedTime(LocalDateTime.now());
					entityBean.setEmpName(employee.getEmpName());
					entityBean.setActive(employee.isActive());
					entityBean.setDept(employee.getDept());
					entityBean.setSalary(employee.getSalary());
					entityBean.setCreatedTime(employee.getCreatedTime());
					emplist.add(entityBean);
				}
				else {
				entityBean.setEmpName(employee.getEmpName());
				entityBean.setActive(employee.isActive());
				entityBean.setDept(employee.getDept());
				entityBean.setSalary(employee.getSalary());
				entityBean.setCreatedTime(LocalDateTime.now());
				
				emplist.add(entityBean);
			}
	    	}
	    	entityRepository.saveAll(emplist);
	    }
	}

